<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {

	function __construct(){ 

        parent::__construct();
        
        $this->load->helper('url'); 
        $this->load->database(); 
        $this->load->model('post_model');
              
    }
	public function index()
	{
		$page_data['getPost']=$this->post_model->getAll();
		$this->load->view('all-posts',$page_data);
	}

	public function signUp()
	{
		if(isset($_POST) && !empty($_POST))
		{
			//print_r($_POST);die;
			$page_data['name'] 		= $this->input->post('name');
			$page_data['email'] 	= $this->input->post('email');
			$page_data['password'] 	= base64_encode($this->input->post('password'));

			$this->db->insert('tbl_user',$page_data);
			redirect(base_url() . 'index.php/posts/login', 'refresh');
		}
		$this->load->view('sign-up');
	}

	public function login()
	{
		if(isset($_POST) && !empty($_POST))
		{
			$this->db->select('email,password');
			$this->db->from('tbl_user');
			$this->db->where('email',$this->input->post('email'));
			$getUser = $this->db->get()->row_array();
	        if($getUser['password']== base64_encode($this->input->post('password')))
	        {
	        	$this->session->set_flashdata('flash_message' , 'Logged In');
	        	redirect(base_url() . 'index.php/posts/allPosts', 'refresh');
	        } 
	        else
	        {
	        	$this->session->set_flashdata('error' , 'Please check Credentials');
	        	redirect(base_url() . 'index.php/posts/login', 'refresh');
	        }                   
		
		}
		
		$this->load->view('login');
	}

	public function allPosts()
	{
		$page_data['getPost'] = $this->post_model->getAll();

		if(isset($_POST['tag']) && !empty($_POST['tag']))
		{
			$page_data['getPost'] = $this->post_model->getAllPost($_POST['tag']);
		}
		
		$this->load->view('all-posts',$page_data);
	}

	public function createNew()
	{
		if(isset($_POST) && !empty($_POST))
		{
			//print_r($_POST);die;
			$page_data['title'] 		= $this->input->post('title');
			$page_data['sub_title'] 	= $this->input->post('sub_title');
			$page_data['tag'] 			= json_encode($this->input->post('tags'));
			$page_data['content'] 		= $this->input->post('content');
			$page_data['added_on'] 			= date('Y-m-d H:i:s');
			$this->db->insert('tbl_post',$page_data);
			$this->session->set_flashdata('flash_message' , 'Post Created Successfully');
	        redirect(base_url() . 'index.php/posts/allPosts', 'refresh');
		}
		
		$this->load->view('create-new-post');
	}

	public function editForm($id)
	{

		$postData['data'] 	= $this->post_model->getPost($id);
		$this->load->view('edit-post',$postData);
	}
	public function editPost()
	{
		if(isset($_POST) && !empty($_POST))
		{
			//print_r($_POST);die;
			$page_data['title'] 		= $this->input->post('title');
			$page_data['sub_title'] 	= $this->input->post('sub_title');
			$page_data['tag'] 			= json_encode($this->input->post('tags'));
			$page_data['content'] 		= $this->input->post('content');
			$this->db->where('id',$this->input->post('id'));
			$this->db->update('tbl_post',$page_data);
			$this->session->set_flashdata('flash_message' , 'Post Upated Successfully');
	        redirect(base_url() . 'index.php/posts/allPosts', 'refresh');
		}
	}
	function deleteRecord()
	{

		$id=$this->input->post('id');
		$res = $this->post_model->deleterecords($id);	
		echo json_encode($res);		
	}

	public function viewPost($id)
	{
		$res['res'] = $this->post_model->viewRecord($id);	
		$this->load->view('view-post',$res);
	}
	
}
