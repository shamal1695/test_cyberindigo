<?php if (!defined('BASEPATH'))

exit('No direct script access allowed');

class Post_model extends CI_Model {

          

    function __construct() {   

        parent::__construct();   

    }

    public function getAll()
    {

    	
        $this->db->select('id,title,sub_title,tag,content');
        $this->db->from('tbl_post');
        $query = $this->db->get()->result_array();
        return $query;    
    }

    public function getAllPost($tag)
    {

        $this->db->select('id,title,sub_title,tag,content');
        $this->db->from('tbl_post');
        $this->db->like('tag',$tag);
        $query = $this->db->get()->result_array();
        //echo $this->db->last_query();die;
        //print_r($query);die;
        return $query;    
    }
    
    public function viewRecord($id)
    {

        $this->db->select('id,title,sub_title,tag,content,added_on');
        $this->db->from('tbl_post');
        $this->db->where('id',$id);
        $query = $this->db->get()->row_array();
        //echo $this->db->last_query();die;
        //print_r($query);die;
        return $query;    
    }

    function getPost($id)
    {
    	$this->db->select('id, title,sub_title,tag,content');  

        $this->db->from('tbl_post');

        $this->db->where('id',$id);

        $query  = $this->db->get()->row_array();

        return $query;

    }
    function deleterecords($id)
    {
    	$this->db->where('id',$id);
    	$this->db->delete('tbl_post');
		return 'success';
    }
}