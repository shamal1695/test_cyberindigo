<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <?php if($this->session->flashdata('flash_message')): ?> 
             <div class="alert alert-success background-success"><strong>Success!</strong><?php echo $this->session->flashdata('flash_message'); ?>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="icofont icofont-close-line-circled text-white"></i>
                  </button>
             </div>
               <?php endif;  
                if($this->session->flashdata('error')){ ?>
              <div class="alert alert-danger background-danger"><strong>Error!</strong><?php echo $this->session->flashdata('error');?>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="icofont icofont-close-line-circled text-white"></i>
                  </button>
             </div>  
             <?php } ?>
  <h2>All Posts <a href="<?php echo base_url();?>index.php/posts/createNew" class="btn btn-primary waves-effect waves-light m-t-30">Create New Post</a></h2> 
        <form method="post" action="<?php echo base_url()?>index.php/posts/allPosts" autocomplete="off"> 
            <div class="col-sm-6">   
              <label for="exampleSelect1" class="form-control-label"></label>
              <select class="form-control" ng-model="MyData" name="tag" >
              <option disabled selected value>-- Search By Tag --</option>
              <option value="ABC">ABC</option>
              <option value="PQR">PQR</option>
              <option value="DEF">DEF</option>
              <option value="GHI">GHI</option>
              <option value="ABC">ABC</option>
              <option value="ABC">ABC</option>
              </select>                                 
            </div>            
            <div class="col-sm-3" ng-app="frmApp" ng-controller="frmCtrl" data-ng-init="displayData('usertrade');" id="exchangeblk">
              <input type="submit" name="search" value="search" class="btn btn-primary waves-effect waves-light m-t-30"/>
             <a href="<?php echo base_url()?>index.php/posts/allPosts" class="btn btn-primary waves-effect waves-light m-t-30">Clear</a>
           </div>
                        
                    </div>
                  </form>
                  <hr/>          
  <table class="table table-hover" id="example">
    <thead>
      <tr>
        <th>Sr.no</th>
        <th>Title</th>
        <th>SubTitle</th>
        <th>Tag</th>
        <th>Content</th>
        <th>View</th>
        <th>Edit</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
     <?php if(!empty($getPost)){
        $count = 1;
        //echo '<pre>';print_r($getPost);
        foreach($getPost as $post){?>
      <tr>
        <?php $tag = json_decode($post['tag']);?>
        <td><?php echo $count++; ?></td>
        <td><?php echo $post['title']?></td>
        <td><?php echo $post['sub_title']?></td>
        <td><?php foreach($tag as $t){ echo $t.',';}?></td>
        <td><?php echo $post['content']?></td>
        <td><a class="btn btn-sm" href="<?php echo base_url();?>index.php/posts/viewPost/<?php echo $post['id']?>">View</a></td>
        <td><a class="btn btn-sm" href="<?php echo base_url();?>index.php/posts/editForm/<?php echo $post['id']?>">edit</a></td>
        <td><button type="button" class="btn btn-sm" onclick="deleteRecord(<?php echo $post['id'];?>)">Delete</button></td>
      </tr>
      <?php }
    } 
    else { ?>

    <td><?php echo 'No Records Found'; ?></td>
      
   <?php }?>
     
    </tbody>
  </table>
</div>

</body>
</html>
<script>
 
  function deleteRecord(id) {
    if (confirm("Are you sure?")) {
        $.ajax({
            url: "<?php echo base_url();?>index.php/posts/deleteRecord?>",
            type: 'post',
            data: {id:id},
            success: function () {
                alert('Record Deleted Successfully');
                window.location.reload();
            },
            error: function () {
                alert('Something Went Wrong');
            }
        });
    } else {
        alert(id + " not deleted");
    }
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

<script type="text/javascript">

app.controller('frmCtrl', function($scope,$http,$interval)

{
  $scope.displayData(); 

    stop = $interval(function() 

    {

        $scope.displayData();      

    }, 5000); 

    $scope.displayData= function()    

    {   

        alert('sdfsddsfds');

        $http.get('<?php echo base_url().'index.php/post/getFilter/'?>').then(function(info)

        {  

            $scope.response = info.data;

        });

    },
    $scope.displayData= function()       
     
    {     
        alert($scope.mydateone);die;
        var status = $scope.MyData;
        var start_date = $scope.mydateone;
        var end_date = $scope.mydatetwo;
        var actual_start_date = btoa(start_date);
        var actual_end_date = btoa(end_date);
        var url='<?php echo base_url().'index.php/post/getFilter/'?>';
        $http.get(url+'/'+status+'/'+actual_start_date+'/'+actual_end_date).then(function(info)  
        {  
            $scope.response = info.data;
    
        });
   
    },   

}
</script>