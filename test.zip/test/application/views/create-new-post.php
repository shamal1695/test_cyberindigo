  <!DOCTYPE html>
  <html lang="en">
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.css">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>  

    
  </head>
  <body>

 
  <div class="container" style="margin-top:100px; ">
    <h3><b>Create Post</b></h3>
   <form role="form" action="<?php echo base_url(); ?>index.php/posts/createNew" method="post">
      <div class="form-group">
        <label for="title">Title:<span style="font-size: 13px;color: red;">*</span></label>
        <input type="text" class="form-control" id="title" placeholder="Enter title" name="title" required>
      </div>
      <div class="form-group">
        <label for="sub_title">Sub Title:<span style="font-size: 13px;color: red;">*</span></label>
        <input type="text" class="form-control" id="sub_title" placeholder="Enter Sub title" name="sub_title" required>
      </div>
      <div class="form-group">
        <label for="price">Tags:<span style="font-size: 13px;color: red;">*</span></label>
        <select class="form-control" id="tags" name="tags[]" multiple="multiple">

          <option value="">--Select--</option>
          <option value="ABC">ABC</option>
          <option value="PQR">PQR</option>
          <option value="DEF">DEF</option>
          <option value="GHI">GHI</option>
          <option value="ABC">ABC</option>
          <option value="ABC">ABC</option>
        </select>
      </div>
      <div class="form-group">
        <label for="price">Content:<span style="font-size: 13px;color: red;">*</span></label>
        <textarea class="form-control" id="content" name="content" rows="6" cols="120"></textarea>
        <!-- <input type="text" class="form-control" id="content" name="content" placeholder="Enter Content" required> -->
      </div>
     

      <div class="form-group">
        <input type="submit" name="submit" id="submit" class="btn btn-default" value="Submit">
      </div>
   </form>
        
  </div>
  
  </div>

  </body>
  </html>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.29.2/sweetalert2.all.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css"></link>
  <script src="<?php echo base_url();?>asset/js/select-boxes.js"></script>

    <script src="<?php echo base_url();?>asset/js/selectsplitter.js"></script>
  
   
<script>
  
  jQuery(document).ready( function($){
      // Multiple Select
      $("#tags").select2({
      placeholder: "Select Multiple Tags"
       
      });
    });

</script>