<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Edit Details</h2>
  <form action="<?php echo base_url();?>index.php/welcome/editRecords" method="post">
    <div class="form-group">
      <label for="name">Name:<span style="font-size: 13px;color: red;">*</span></label>
      <input type="text" class="form-control num_restrict" id="name" value="<?php if(!empty($data[0]['name'])){ echo $data[0]['name'];}?>" name="name">
      <input type="hidden" class="form-control num_restrict" id="id" value="<?php if(!empty($data[0]['id'])){ echo $data[0]['id'];}?>" name="id">
      <span id="name_err" class="err-cls" style="font-size: 13px;color: red;"></span>
    </div>
    <div class="form-group">
      <label for="email">Email:<span style="font-size: 13px;color: red;">*</span></label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php if(!empty($data[0]['email'])){ echo $data[0]['email'];}?>">
      <span id="email_err" class="err-cls" style="font-size: 13px;color: red;"></span>
    </div>
    <div class="form-group">
      <label for="phone">Contact Number:</label>
      <input type="number" pattern="\d{3}[\-]\d{3}[\-]\d{4}" class="form-control char_restrict" id="phone" placeholder="Enter phone" name="phone" value="<?php if(!empty($data[0]['phone'])){ echo $data[0]['phone'];}?>">
      <span id="phone_err" class="err-cls" style="font-size: 13px;color: red;"></span>

    </div>
    <div class="form-group">
      <label for="address">Address:</label>
      <textarea class="form-control" id="address" name="address"><?php if(!empty($data[0]['address'])){ echo $data[0]['address'];}?></textarea>
      Characters Remaining <span id="remain" class="text-center" style="font-size: 13px;color: green;">50 </span>
      <span id="address_err" class="err-cls" style="font-size: 13px;color: red;"></span>
    </div>
    <div class="form-group">
      <label for="gender">Gender:<span style="font-size: 13px;color: red;">*</span></label>
      <input type="radio"  id="gender" name="gender" value="Male" <?php if(!empty($data[0]['gender']) && $data[0]['gender']=="Male") echo 'checked="checked"' ?>> Male
      <input type="radio"  id="gender" name="gender" value="Female" <?php if(!empty($data[0]['gender']) and $data[0]['gender']=="Female") echo 'checked="checked"' ?>> Female
      <span id="gender_err" class="err-cls" style="font-size: 13px;color: red;"></span>
    </div>
    <div class="form-group">
      <label for="dob">DOB:</label>
      <input type="date" class="form-control" id="dob" placeholder="Enter dob" name="dob" value="<?php if(!empty($data[0]['dob'])){ echo $data[0]['dob'];}?>">
    </div>
    <div class="form-group">
      <label for="address">Hobbies:<span style="font-size: 13px;color: red;">*</span></label>
      <input type="checkbox" name="hobby[]" value="Chess" id="hobby" <?php if(!empty($data[0]['hobbies']) && $data[0]['hobbies']=="Chess") echo 'checked="checked"' ?>>Chess
      <input type="checkbox" name="hobby[]" value="Music" id="hobby" <?php if(!empty($data[0]['hobbies']) && $data[0]['hobbies']=="Music") echo 'checked="checked"' ?>>Music
      <input type="checkbox" name="hobby[]" value="Cricket" id="hobby" <?php if(!empty($data[0]['hobbies']) && $data[0]['hobbies']=="Cricket") echo 'checked="checked"' ?>>Cricket
      <input type="checkbox" name="hobby[]" value="Reading" id="hobby" <?php if(!empty($data[0]['hobbies']) && $data[0]['hobbies']=="Reading") echo 'checked="checked"' ?>>Reading
                
      <span id="hobby_err" class="err-cls" style="font-size: 13px;color: red;"></span>
    </div>
    <div class="checkbox">
      
    </div>
    <button type="button" name="submit" id="submit"  class="btn btn-default">Submit</button>
  </form>
</div>

</body>
</html>

<script>
  $(document).ready(function(){

  $('#submit').click(function(){
    $('.err-cls').html(''); 
          var name    =$('#name').val();
          var email   =$('#email').val();
          var phone   =$('#phone').val();
          var address =$('#address').val();
          var dob     =$('#dob').val();
          var hobbies =$('#hobbies').val();
          var length  = $.trim($("#name").val()).length;
          var pattern   = '/^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i' ;
          //var pattern = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          //alert($('input[type="checkbox"]:checked').length);
          //alert($('#phone').val().length);
          var flag = 0;
          if(name=='')
          {
            $('#name_err').html('Please Enter name').css('color','red');  
            flag = 1;
          }else if (length==0) 
          {
            $('#name_err').html('Spaces not allowed').css('color','red');  
            flag = 1;
          }
          if(email==''){
                  
            $('#email_err').html('Please Enter email id').css('color','red');  
            flag = 1;
          }
          /*else if(!pattern.test(email))
          {
            $('#email_err').html('Please Enter valid email id').css('color','red');  
            flag = 1;
          }​*/
          
          if($('#phone').val().length > 1)
          {
            if($('#phone').val().length != 10)
            {
                    
              $('#phone_err').html('Contact number should be 10 digit').css('color','red');  
              flag = 1;
            }
          }
          if($('input[name=gender]:checked').length <= 0){
                  
            $('#gender_err').html('Please select gender').css('color','red');  
            flag = 1;
          }
          if($('input[type="checkbox"]:checked').length <3){
                  
            $('#hobby_err').html('Please select minimum 3 hobbies').css('color','red');  
            flag = 1;
          }
          
          if(flag == 1)
          {
            return false;
          } 
          else 
          {
              $('#submit').attr('type','submit'); 
              $('#submit').click(); 
              return true;  
          }
  });
});

$(".num_restrict").keypress(function(event){
      var inputValue = event.which;
      $('.tclass').html('');
      $('.err-cls').html('');
      if(!(inputValue >= 65 && inputValue <= 122) && (inputValue != 32 && inputValue!=8 && inputValue != 0 && inputValue!=46 && inputValue!=44 && inputValue!=13  && inputValue!=46)) { 
        $(this).after('<span class="tclass err-cls">Please enter only characters</span>');
        $('.tclass').css('color','red');
        event.preventDefault(); 
      }
      else
      {
        $('.tclass').html('');
        $('.err-cls').html('');
      }
});

$(".char_restrict").bind("keydown", function (event) {
        $('.tclass').html('');
        $('.err-cls').html('');
        if(event.keyCode == 110     ||event.keyCode == 46     || event.keyCode   == 8      ||  event.keyCode  == 9  || event.keyCode  == 27     || event.keyCode == 13 || event.keyCode == 190 ||
          (event.keyCode == 65     && event.ctrlKey   === true) || (event.keyCode  == 61 && event.shiftKey === true) ||
          (event.keyCode >= 35     && event.keyCode   <= 39)) {
          return;
        } else {
          if(event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
             $(this).after('<span class="tclass err-cls">Please enter numeric values</span>');
             $('.tclass').css('color','red');
             event.preventDefault();
          }
          else
          {
            $('.tclass').html('');
            $('.err-cls').html('');
          }
        }
    });

$('#address').keypress(function(e) {
    var tval = $('#address').val(),
        tlength = tval.length,
        set = 50,
        remain = parseInt(set - tlength);
    $('#remain').text(remain);
    if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
        $('#address').val((tval).substring(0, tlength - 1));
        return false;
    }
})
</script>
