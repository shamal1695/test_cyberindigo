<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>List Of Student <a href="<?php echo base_url();?>index.php/welcome/studentForm" class="btn btn-sm">Add New</a></h2>           
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact No</th>
        <th>Address</th>
        <th>Gender</th>
        <th>DOB</th>
        <!-- <th>Hobbies</th> -->
        <th>Edit</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php if(!empty($data)){
        foreach($data as $d){?>
      <tr>
        <td><?php echo $d['id']?></td>
        <td><?php echo $d['name']?></td>
        <td><?php echo $d['email']?></td>
        <td><?php echo $d['phone']?></td>
        <td><?php echo $d['address']?></td>
        
        <td><?php echo $d['gender']?></td>
        <td><?php echo $d['dob']?></td>
        <td><a class="btn btn-sm" href="<?php echo base_url();?>index.php/welcome/editForm/<?php echo $d['id']?>">edit</a></td>
        <td><button type="button" class="btn btn-sm" onclick="deleteRecord(<?php echo $d['id'];?>)">Delete</button></td>
      </tr>
      <?php }
    } 
    else { ?>

    <td><?php echo 'No Records Found'; ?></td>
      
   <?php }?>
    </tbody>
  </table>
</div>

</body>
</html>
<script>
  /*$(document).on("click", ".delete", function() { 
  //alert($(this).attr("data-id"));
    $.ajax({
      url: "<?php echo base_url();?>index.php/welcome/deleteRecord?>",
      type: "POST",
      data: {
              id: $(this).attr("data-id")
            },
      success: function(response){

        //alert('Record Deleted1');
        if(response=='success')
        {
          //alert('Record Deleted');
        }
        
      }
    });
  });
*/
  function deleteRecord(id) {
    if (confirm("Are you sure?")) {
        $.ajax({
            url: "<?php echo base_url();?>index.php/welcome/deleteRecord?>",
            type: 'post',
            data: {id:id},
            success: function () {
                alert('Record Deleted Successfully');
                window.location.reload();
            },
            error: function () {
                alert('Something Went Wrong');
            }
        });
    } else {
        alert(id + " not deleted");
    }
}
</script>