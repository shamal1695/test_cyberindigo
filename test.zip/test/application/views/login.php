  <!DOCTYPE html>
  <html lang="en">
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>
  <body>

 
  <div class="container" style="margin-top:100px; ">
    <?php if($this->session->flashdata('flash_message')): ?> 
             <div class="alert alert-success background-success"><strong>Success!</strong><?php echo $this->session->flashdata('flash_message'); ?>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="icofont icofont-close-line-circled text-white"></i>
                  </button>
             </div>
               <?php endif;  
                if($this->session->flashdata('error')){ ?>
              <div class="alert alert-danger background-danger"><strong>Error!</strong><?php echo $this->session->flashdata('error');?>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="icofont icofont-close-line-circled text-white"></i>
                  </button>
             </div>  
             <?php } ?>
    <h3><b>Sign In</b></h3>
   <form role="form" action="<?php echo base_url(); ?>index.php/posts/login" method="post">
      <div class="form-group">
        <label for="email">Email:<span style="font-size: 13px;color: red;">*</span></label>
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
      </div>
      <div class="form-group">
        <label for="price">Password:<span style="font-size: 13px;color: red;">*</span></label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password">
      </div>

      <div class="form-group">
        <input type="submit" name="submit" id="submit" class="btn btn-default" value="Submit">
      </div>
   </form>
        
  </div>
  
  </div>

  </body>
  </html>

