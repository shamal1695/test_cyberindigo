<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
 <form role="form" enctype="multipart/form-data">
    <div class="form-group">
      <label for="name">Name:<span style="font-size: 13px;color: red;">*</span></label>
      <input type="text" class="form-control" id="name" placeholder="Enter name" name="name">
    </div>
    <div class="form-group">
      <label for="price">Price:<span style="font-size: 13px;color: red;">*</span></label>
      <input type="price" class="form-control" id="price" placeholder="Enter price" name="price">
    </div>
    <div class="form-group">
      <label for="price">Select Image:</span></label>
      <input type="file" class="form-control" id="img" name="file1" alt="">
    </div>
      
</div>
<div class="form-group">
    <button type="button" name="submit" id="submit" class="btn btn-default">Submit</button>
    </div>
 </form>
</div>

</body>
</html>

<script>


 $(document).on("click", "#submit", function(){


    //alert('in');

        var filesSelected = document.getElementById('img').files; // FileList object
        var filesSelected = $('#img').prop('files'); // with jQuery
        var filesSelected = $('#img')[0].files; // with jQuery
        var filesSelected = $('input[type=file]')[0].files;  // with jQuery
        console.log(filesSelected);


    var form_data = new FormData();
    var name        = $('#name').val();
    var price       = $('#price').val();
    //var file_data = $('#img').prop('files')[0];  
    //var file_data   = document.getElementById("img").files;
    /*var totalfiles = document.getElementById('img').files.length;
   for (var index = 0; index < totalfiles; index++) {
      form_data.append("img[]", document.getElementById('img').files[index]);
   }*/
    //alert(file_data);
    //file_data =  $('input[type=file]')[0].files;
    form_data.append('name',name);
    form_data.append('price',price);
    form_data.append('file_data',filesSelected);  
    form_data.append('file', $('#img').get(0).files);   
  alert(form_data);
    $.ajax({
        url:'<?php echo base_url()?>index.php/welcome/insertRecords',
        type: 'POST',
        cache: false,
        processData: false,
        contentType: false,   
        data: form_data,
       success: function(response)
       {
           //alert("success");
          if(response == 'success')
          {
            alert('success');              
          }
       },
       error: function(){

           alert('error'); 
      }
   });
   
   return false;
 });
</script>
