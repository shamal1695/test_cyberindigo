  <!DOCTYPE html>
  <html lang="en">
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>
  <body>

 
  <div class="container" style="margin-top:100px; ">
    <h3><b>Sign Up</b></h3>
   <form role="form" action="<?php echo base_url(); ?>index.php/posts/signUp" method="post">
      <div class="form-group">
        <label for="name">Name:<span style="font-size: 13px;color: red;">*</span></label>
        <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" required>
      </div>
      <div class="form-group">
        <label for="email">Email:<span style="font-size: 13px;color: red;">*</span></label>
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
      </div>
      <div class="form-group">
        <label for="price">Password:<span style="font-size: 13px;color: red;">*</span></label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
      </div>

      <div class="form-group">
        <input type="submit" name="submit" id="submit" class="btn btn-default" value="Submit">
      </div>
   </form>
        
  </div>
  
  </div>

  </body>
  </html>

