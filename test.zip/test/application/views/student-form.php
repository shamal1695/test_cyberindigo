<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <form action="" method="post">
    <div class="form-group">
      <label for="name">Name:<span style="font-size: 13px;color: red;">*</span></label>
      <input type="text" class="form-control num_restrict" id="name" placeholder="Enter name" name="name">
    </div>
    <div class="form-group">
      <label for="price">Price:<span style="font-size: 13px;color: red;">*</span></label>
      <input type="price" class="form-control" id="price" placeholder="Enter price" name="price">
    </div>
    <div class="form-group">
      <label for="price">Select Image:*</span></label>
      <input type="file" class="form-control" id="img" name="img">
    </div>
      
</div>
    <button type="button" name="submit" id="submit" onclick="insertRecords()" class="btn btn-default">Submit</button>
  </form>
</div>

</body>
</html>

<script>

  function insertRecords(id) {
   
    var file_data           = document.getElementById("img").files[0];
        $.ajax({
            url: "<?php echo base_url();?>index.php/welcome/insertRecords?>",
            type: 'post',
            data: {id:id},
            success: function () {
                alert('Record Deleted Successfully');
                window.location.reload();
            },
            error: function () {
                alert('Something Went Wrong');
            }
        });
   


  $(document).ready(function(){

  $('#submit').click(function(){
    $('.err-cls').html(''); 
          var name    =$('#name').val();
          var email   =$('#email').val();
          var phone   =$('#phone').val();
          var address =$('#address').val();
          var dob     =$('#dob').val();
          var hobbies =$('#hobbies').val();
          var length  = $.trim($("#name").val()).length;
          var pattern   = '/^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i' ;
          //var pattern = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          //alert($('input[type="checkbox"]:checked').length);
          var flag = 0;
          if(name=='')
          {
            $('#name_err').html('Please Enter name').css('color','red');  
            flag = 1;
          }else if (length==0) 
          {
            $('#name_err').html('Spaces not allowed').css('color','red');  
            flag = 1;
          }
          if(email==''){
                  
            $('#email_err').html('Please Enter email id').css('color','red');  
            flag = 1;
          }
          /*else if(!pattern.test(email))
          {
            $('#email_err').html('Please Enter valid email id').css('color','red');  
            flag = 1;
          }​*/
          if($('#phone').val().length > 1)
          {
            if($('#phone').val().length != 10)
            {
                    
              $('#phone_err').html('Contact number should be 10 digit').css('color','red');  
              flag = 1;
            }
          }
          if($('input[name=gender]:checked').length <= 0){
                  
            $('#gender_err').html('Please select gender').css('color','red');  
            flag = 1;
          }
          if($('input[type="checkbox"]:checked').length <3){
                  
            $('#hobby_err').html('Please select minimum 3 hobbies').css('color','red');  
            flag = 1;
          }
          
          if(flag == 1)
          {
            return false;
          } 
          else 
          {
              $('#submit').attr('type','submit'); 
              $('#submit').click(); 
              return true;  
          }
  });
});



</script>
